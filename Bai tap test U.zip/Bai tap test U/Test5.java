
public class Test5 {
public static int[] f5(int[]first, int[]second ) {
	int[]suba;
	for (int i=0; i<first.length; i++) {
		for (int j=0; j<second.length; j++) {
			if (first[i] == second[j]) {
				suba[i]=first[i];
				return suba[];
				System.out.print(suba[i] +" ");
			}
			else return null;
		}
	}
}
}
