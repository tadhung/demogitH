
public class Test3 {
public static char f(char[] a, int start, int len) {
	if (len>a.length&&start<1) return null;
	else {
		char[] b;
		for (int i=start; i<len;i++) {
			//b[i]=a[i];
			return a[i];
		}
	}
}
}
