
public class Test1 {
public static void main(String args[]) {
	int inputArr[]= {1,2,3,4,5};
	centerarray(inputArr[]);
}
	public static int centerarray(int inputArray[]) {
	int l = inputArray.length;
		if ((l%2) == 0) 	{
		return 0;
		System.out.println("The input array has not odd elements, result 0");
	}
		else {
			for (int i=0; i<l; i++) {
				if (inputArray[i]>= inputArray[(l+1)/2]) {
					return 0;
					System.out.println("The input array has not a centerred array, result 0");
					break;
				}
				else return 1;
				System.out.println("The input array is a centerred array, result 1");
			}
		}
	}
}
