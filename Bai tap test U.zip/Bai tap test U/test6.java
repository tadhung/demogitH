
public class test6 {
	public static int f6(int[] a) {
		int idx, sum1, sum2;
		sum1=sum2=0;
		for (idx=1; idx<a.length; idx++) {
			sum1=sum1+a[idx-1];
			for (int j=idx+1;j<a.length; idx++) sum2=sum2+a[idx+1];	
			if (sum1==sum2) {
				return idx;
				System.out.println("POE is :" +idx);
				}
				else { 
					return -1;
					System.out.println("No POE ");
			      }
			
		}
}
}