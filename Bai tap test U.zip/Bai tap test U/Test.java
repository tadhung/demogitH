//import java.util.*;
public class Test {

		public static void main(String args[]) {
			int[] inputArr= {3,2,3,4,5};
			int t;
			t= centerA(inputArr);
			if (t==1) System.out.println("The input array is a centerred array, result: "+t);
			else System.out.println("The input array is not a centerred array, result: " +t);
		}
			public static int centerA(int[] inputArray) {
			int l = inputArray.length;
			int m=0;
				if((l%2) == 0) m= 0;
				else {
					for (int i=0; i<l; i++) {						
						if (inputArray[i]<= inputArray[l/2]) {
							m = 0;
						}
						else m = 1;	
					}
				}
				return m;
			}
		
}
