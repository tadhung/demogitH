
public class Test2 {
/* Take an array of integer. Calculate sums of the even and odd numbers in the array
 * return sum
 */
	public static void main(String args[]) {
		int inputArr[]= {1,2,3,4,5};
		int s;
		s=test2(inputArr);
		System.out.println("sums of the even and odd numbers in the array is: "+ s);
	}
	public static int test2(int arr[]) {
		int X, Y, sum;
		X=Y=0;
		for (int i=0; i<arr.length; i++) {
			if(arr[i]%2==0) Y=Y+arr[i];
			else X=X+arr[i];	
		}
		sum=X-Y;
		return sum;	
	}
	
}
